data:extend(
{
	{
		type = "custom-input",
		name = "WideChests_rotate-blueprint-clockwise",
		key_sequence = ""
	},
	{
		type = "custom-input",
		name = "WideChests_rotate-blueprint-couterclockwise",
		key_sequence = ""
	}
})
